<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Rka extends CI_Controller {

	function __contruct()
	{	
		parent::__construct();
	}
	function tambah_rka()
	{
		
        $data['page_title']= 'Langkah I Mapping Output';
        $this->template->set('title', 'Proses I');   
        
        $this->template->load('template','anggaran/rka/tambah_rka',$data) ; 
   }
   
   function tambah_rkaII()
	{
		
        $data['page_title']= 'Langkah 3 Isi Volume';
        $this->template->set('title', 'Langkah 3');   
        
        $this->template->load('template','anggaran/rka/tambah_rkaII',$data) ; 
   }
   
   function tambah_rkaIII()
	{
		
        $data['page_title']= 'Langkah 5 Isi Volume';
        $this->template->set('title', 'Langkah 5');   
        
        $this->template->load('template','anggaran/rka/tambah_rkaIII',$data) ; 
   }
   
   function tambah_rkaIV()
	{
		
        $data['page_title']= 'Langkah VI LOKASI';
        $this->template->set('title', 'LOKASI');   
        
        $this->template->load('template','anggaran/rka/tambah_rkaIV',$data) ; 
   }
   
   function tambah_rkaV()
	{
		
        $data['page_title']= 'Langkah VI KOMPONEN';
        $this->template->set('title', 'KOMPONEN');   
        
        $this->template->load('template','anggaran/rka/tambah_rkaV',$data) ; 
   }
   
   function unit_harga()
	{
		
        $data['page_title']= 'Menentukan Unit Price';
        $this->template->set('title', 'Menentukan Unit Price');   
        
        $this->template->load('template','anggaran/rka/hargaunit',$data) ; 
   }
   
   function grouping()
	{
		
        $data['page_title']= 'Langkah I Grouping Output';
        $this->template->set('title', 'Poses 1');   
        
        $this->template->load('template','anggaran/rka/grouping',$data) ; 
   }
   
   function proyeksi()
	{
		
        $data['page_title']= 'Langkah 4 Proyeksi';
        $this->template->set('title', 'Langkah 4');   
        
        $this->template->load('template','anggaran/rka/proyeksi',$data) ; 
   }
   
   

    function config_skpd(){
            $skpd     = $this->session->userdata('kdskpd');
            $sql = "SELECT kddept,nmdept,'0' as statu FROM  t_dept  WHERE kddept = '$skpd'";
            $query1 = $this->db->query($sql);  
    		
    		$test = $query1->num_rows();
    		
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
                $result = array(
                            'id' => $ii,        
                            'kd_skpd' => $resulte['kddept'],
                            'nm_skpd' => $resulte['nmdept'],
                            'statu' => $resulte['statu']
                            );
                            $ii++;
            }
    		
    
    		
    		
            echo json_encode($result);
        	$query1->free_result();   
        }
            
    function pprog($cskpd='') {
            
            $lccr = $this->input->post('q');
            $sql  = " SELECT kdprogram,nmprogram FROM t_program  where kddept='$cskpd' and ( upper(kdprogram) like upper('%$lccr%') or upper(nmprogram) like upper('%$lccr%') )";
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii     = 0;
            foreach($query1->result_array() as $resulte)
            { 
                $result[] = array(
                            'id' => $ii,        
                            'kdprogram'  => $resulte['kdprogram'],  
                            'nmprogram'  => $resulte['nmprogram']
                            );
                            $ii++;
            }
            echo json_encode($result);
        	   
    	}
        
    function pgiat($cskpd='',$cprog='') {
            
            $lccr = $this->input->post('q');
            $sql  = " SELECT kdgiat,nmgiat FROM t_giat where kddept='$cskpd' and kdprogram='$cprog' and ( upper(kdgiat) like upper('%$lccr%') or upper(nmgiat) like upper('%$lccr%') )";
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii     = 0;
            foreach($query1->result_array() as $resulte)
            { 
                $result[] = array(
                            'id' => $ii,        
                            'kdgiat'  => $resulte['kdgiat'],  
                            'nmgiat'  => $resulte['nmgiat']
                            );
                            $ii++;
            }
            echo json_encode($result);
        	   
    	}
        
    function poutput($cskpd='',$cprog='',$cgiat='') {
            
            $lccr = $this->input->post('q');
            $sql  = " SELECT kdoutput,nmoutput,satuan,vol,vol1,vol2,vol3,vol4,harga,total,harga1,total1,harga2,total2,harga3,total3,harga4,total4 FROM d_item_output 
            where kddept='$cskpd' and kdprogram='$cprog' and kdgiat='$cgiat' and ( upper(kdoutput) like upper('%$lccr%') or upper(nmoutput) like upper('%$lccr%') )";
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii     = 0;
            foreach($query1->result_array() as $resulte)
            { 
                $result[] = array(
                            'id' => $ii,        
                            'kdoutput'  => $resulte['kdoutput'],  
                            'nmoutput'  => $resulte['nmoutput'],
                            'satuan'  => $resulte['satuan'],
                            'vol1'  => $resulte['vol'],
                            'vol2'  => $resulte['vol1'],
                            'vol3'  => $resulte['vol2'],
                            'vol4'  => $resulte['vol3'],
                            'vol5'  => $resulte['vol4'],
                            'harga1'  => $resulte['harga'],
                            'total1'  => number_format($resulte['total']),
                            'harga2'  => $resulte['harga1'],
                            'total2'  => number_format($resulte['total1']),
                            'harga3'  => $resulte['harga2'],
                            'total3'  => number_format($resulte['total2']),
                            'harga4'  => $resulte['harga3'],
                            'total4'  => number_format($resulte['total3']),
                            'harga5'  => $resulte['harga4'],
                            'total5'  => number_format($resulte['total4'])
                            );
                            $ii++;
            }
            echo json_encode($result);
        	   
    	}
    function plokasi() {
            
            $lccr = $this->input->post('q');
            $sql  = " SELECT * FROM t_lokasi where  upper(kdlokasi) like upper('%$lccr%') or upper(nmlokasi) like upper('%$lccr%') ";
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii     = 0;
            foreach($query1->result_array() as $resulte)
            { 
                $result[] = array(
                            'id' => $ii,        
                            'kdlokasi'  => $resulte['kdlokasi'],  
                            'nmlokasi'  => $resulte['nmlokasi']
                            
                            );
                            $ii++;
            }
            echo json_encode($result);
        	   
    	}
    function select_new_renstra($cskpd='',$cprog='',$cgiat='') {
    
    		$sql = "select kdnewoutput,kdoutput,nmoutput,sat,satlama,pagu,ket from t_new_output where kdprogram='$cprog' and kdgiat='$cgiat' order by kdoutput";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,
                            'kdnewoutput' => $resulte['kdnewoutput'],        
                            'kdoutput' => $resulte['kdoutput'],  
                            'nmoutput' => $resulte['nmoutput'],  
                            'sat' => $resulte['sat'], 
                            'satlama' => $resulte['satlama'],
                            'harga' => number_format($resulte['pagu']),                        
                            'harga1' => $resulte['pagu'],
                            'ket' => $resulte['ket']                            
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
    function select_old_output($cskpd='',$cprog='',$cgiat='') {
            
    		$sql = "SELECT a.kdprogram,a.kdgiat,a.kdoutput,b.nmoutput,b.sat,SUM(a.jumlah) AS hargaoutput FROM d_item a 
                    INNER JOIN t_output b ON a.kdgiat=b.kdgiat AND a.kdoutput=b.kdoutput WHERE a.kddept='$cskpd' 
                    AND a.kdprogram='$cprog' AND a.kdgiat='$cgiat' and a.kdoutput not in(select kdoutput from t_new_output where kdprogram='$cprog' AND kdgiat='$cgiat' )
                    GROUP BY a.kdprogram,a.kdgiat,a.kdoutput,b.nmoutput";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdoutput' => $resulte['kdoutput'],  
                            'nmoutput' => $resulte['nmoutput'],  
                            'sat' => $resulte['sat'],
                            'hargasat1' => $resulte['hargaoutput'],
                            'hargasat' => number_format($resulte['hargaoutput'])                            
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
        function select_old_komponen($cskpd='',$cprog='',$cgiat='',$coutput) {
            
    		$sql = "SELECT a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,a.kdoutput,b.kdkmpnen,c.urkmpnen,SUM(b.jumlah)AS pagu,a.ket FROM t_new_output a 
                    INNER JOIN d_item b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdoutput 
                    INNER JOIN d_kmpnen c  ON b.kddept=c.kddept AND b.kdprogram=c.kdprogram AND b.kdgiat=c.kdgiat AND b.kdoutput=c.kdoutput AND b.kdkmpnen=c.kdkmpnen
                    WHERE a.kddept='$cskpd' AND a.kdprogram='$cprog' AND a.kdgiat='$cgiat' AND a.kdnewoutput='$coutput' AND a.ket<>'5'
                    GROUP BY a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,a.kdoutput,b.kdkmpnen,c.urkmpnen,a.ket ";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdkmpnen' => $resulte['kdkmpnen'],  
                            'nmoutput' => $resulte['nmoutput'],  
                            'pagu' => $resulte['pagu']     
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        } 
        
        function select_new_output($cskpd='',$cprog='',$cgiat='') {
            
    		$sql = "SELECT * from d_new_output WHERE kddept='$cskpd' 
                    AND kdprogram='$cprog' AND kdgiat='$cgiat' GROUP BY kdprogram,kdgiat,kdoutput";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdoutput' => $resulte['kdoutput'],
                            'kdrenstra' => $resulte['kdrenstra'],  
                            'nmoutput' => $resulte['nmoutput'],  
                            'satuan' => $resulte['satuan'],
                            'harga' => $resulte['harga']                          
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
    function simpan_new_output(){
    //skpd:mskpd,prog:mprog,giat:mgiat,kdrenstra:ckdrenstra,output:ckdoutput,nmoutput:cnmoutput,satuan:csatuan,harga:charga
            //$tabel    = $this->input->post('tabel');
            $skpd     = $this->input->post('skpd');
            $kdprog   = $this->input->post('prog');       
            $kdgiat    = $this->input->post('giat');
            $kdrenstra      = $this->input->post('kdrenstra');
            $kdoutput   = $this->input->post('kdoutput');
            $nmoutput  = $this->input->post('nmoutput');
            $satuan = $this->input->post('satuan');
            $nsatuan = $this->input->post('nsat');
            $harga    = $this->input->post('harga');      
                   
            //$usernm   = $this->session->userdata('pcNama');
            $update     = date('y-m-d H:i:s');      
            $msg        = array();
    
    		// Simpan Header //
           
                $sql = "delete from d_new_output where kddept='$skpd' and kdprogram='$kdprog' and kdgiat='$kdgiat' and kdoutput='$kdoutput'";
    			$asg = $this->db->query($sql);
    			
    
                if ($asg){
                    
    				$sql = "insert into d_new_output(kddept,kdprogram,kdgiat,kdoutput,kdrenstra,nmoutput,satuan,newsat,harga) 
                            values('$skpd','$kdprog','$kdgiat','$kdoutput','$kdrenstra','$nmoutput','$satuan','$nsatuan','$harga')";
                    $asg = $this->db->query($sql);
    
    
    
    
                    if (!($asg)){
                       $msg = array('pesan'=>'0');
                       echo json_encode($msg);
                        exit();
                    } else {
                        $msg = array('pesan'=>'1');
                        echo json_encode($msg);
                    }             
                } else {
                    $msg = array('pesan'=>'0');
                    echo json_encode($msg);
                    exit();
                }
                
            
        } 
    function simpan_output(){
            //$skpd     = $this->input->post('skpd');
//            $kdprog   = $this->input->post('prog');       
//            $kdgiat    = $this->input->post('giat');
//            $kdoutput   = $this->input->post('kdoutput');
//            $vol1 =   $this->input->post('vol1');
//            $vol2 =   $this->input->post('vol2');
//            $vol3 =   $this->input->post('vol3');
//            $vol4 =   $this->input->post('vol4');
//            $vol5 =   $this->input->post('vol5');
//                
//                    
//    				$sql = "update d_item_output set vol='$vol1',vol1='$vol2',vol2='$vol3',vol3='$vol4',vol4='$vol5'
//                            where kddept='$skpd' and kdprogram='$kdprog' and kdgiat='$kdgiat' and kdoutput='$kdoutput'";
//                    $asg = $this->db->query($sql);
        $query        = $this->input->post('st_query');
        $asg          = $this->db->query($query);
    
    
    
                    if (!($asg)){
                       $msg = array('pesan'=>'0');
                       echo json_encode($msg);
                        exit();
                    } else {
                        $msg = array('pesan'=>'1');
                        echo json_encode($msg);
                    }             
                
                
            
        }
     function update_harga(){
                    
        $query        = $this->input->post('st_query');
        $asg          = $this->db->query($query);
    
    
    
                    if (!($asg)){
                       $msg = array('pesan'=>'0');
                       echo json_encode($msg);
                        exit();
                    } else {
                        $msg = array('pesan'=>'1');
                        echo json_encode($msg);
                    }             
                
                
            
        }
     function update_output(){
           $query        = $this->input->post('st_query');
           $asg          = $this->db->query($query);
    
                    if (!($asg)){
                       $msg = array('pesan'=>'0');
                       echo json_encode($msg);
                        exit();
                    } else {
                        $msg = array('pesan'=>'1');
                        echo json_encode($msg);
                    }             
                
                
            
        }
        
    function simpan_komponen(){
        
            $tabel  = $this->input->post('tabel');
            $lckolom = $this->input->post('kolom');
            $lcnilai = $this->input->post('nilai');
            //$lckolom1 = $this->input->post('kolom1');
//            $lcnilai1 = $this->input->post('nilai1');
            $cprog = $this->input->post('cprog');
            $cgiat = $this->input->post('cgiat');
            $ckdoutput = $this->input->post('ckdoutput');
            $ckdkmpnen = $this->input->post('ckdkmpnen');
    
     
            
            $sql = "select kdkmpnen from $tabel where kdkmpnen='$ckdkmpnen' and kdprogram='$cprog' and  kdgiat='$cgiat' and kdnewoutput='$ckdoutput'";
            $res = $this->db->query($sql);
            if($res->num_rows()>0){
                echo '1';
            }else{
                $sql = "insert into $tabel $lckolom values $lcnilai";
                $asg = $this->db->query($sql);
                //$sql1 = "insert into d_kmpnen $lckolom1 values $lcnilai1";
//                $asg1 = $this->db->query($sql1);
                if($asg){
                    echo '2';
                }else{
                    echo '0';
                }
            }
        }
     function simpan_lokasi(){
        
            $tabel  = $this->input->post('tabel');
            $lckolom = $this->input->post('kolom');
            $lcnilai = $this->input->post('nilai');
            $lckolom = $this->input->post('kolom');
            $cprog = $this->input->post('cprog');
            $cgiat = $this->input->post('cgiat');
            $ckdoutput = $this->input->post('ckdoutput');
            $ckdlokasi = $this->input->post('ckdlokasi');
    
     
            
            $sql = "select kdlokasi from $tabel where kdlokasi='$ckdlokasi' and kdprogram='$cprog' and  kdgiat='$cgiat' and kdoutput='$ckdoutput'";
            $res = $this->db->query($sql);
            if($res->num_rows()>0){
                echo '1';
            }else{
                $sql = "insert into $tabel $lckolom values $lcnilai";
                $asg = $this->db->query($sql);
                
                if($asg){
                    echo '2';
                }else{
                    echo '0';
                }
            }
        }
     
     function update_komponen(){
        $query = $this->input->post('st_query');
        $asg = $this->db->query($query);
        if($asg){
            echo '1';
        }else{
            echo '0';
        }
  

    }
    
    function hapus_komponen(){
        $dept= $this->input->post('dept');
        $prog = $this->input->post('prog');
        $giat = $this->input->post('giat');
        $output = $this->input->post('outout');
        $kdkmpnen = $this->input->post('ckdkmpnen');
        $msg = array();
        $sql = "delete from t_new_komponen where kddept='$dept' and kdprogram='$prog' and kdgiat='$giat' and kdnewoutput='$output' and kdkmpnen='$kdkmpnen'";
        $asg = $this->db->query($sql);
    
    	
    
    	if ($asg){
            $msg = array('pesan'=>'1');
            echo json_encode($msg);
        } else {
            $msg = array('pesan'=>'0');
            echo json_encode($msg);
            
        }
    }
    
    function hapus_lokasi(){
        $dept= $this->input->post('dept');
        $prog = $this->input->post('prog');
        $giat = $this->input->post('giat');
        $output = $this->input->post('outout');
        $clokasi = $this->input->post('clokasi');
        $msg = array();
        $sql = "delete from d_item_output_lokasi where kddept='$dept' and kdprogram='$prog' and kdgiat='$giat' and kdoutput='$output' and kdlokasi='$clokasi'";
        $asg = $this->db->query($sql);
    
    	
    
    	if ($asg){
            $msg = array('pesan'=>'1');
            echo json_encode($msg);
        } else {
            $msg = array('pesan'=>'0');
            echo json_encode($msg);
            
        }
    }
        
     function simpan_grouping(){
                $skpd     = $this->session->userdata('kdskpd');
                $prog = $this->input->post('prog');
                $giat = $this->input->post('giat');
                
               
                $sql = "delete from d_new_output1 where kddept='$skpd' and kdprogram='$prog' and kdgiat='$giat' ";
    			$asg = $this->db->query($sql);
                if ($asg){
    			$sql2="SELECT a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,SUM(a.pagu) AS pagu,a.ket FROM t_new_output a where a.ket <>'5' and a.kddept='$skpd' and a.kdprogram='$prog' and a.kdgiat='$giat'
                        GROUP BY a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput";
                     $sqlp2=$this->db->query($sql2);
                     foreach ($sqlp2->result() as $rowp2)
                        {
                           
                            $kddept=$rowp2->kddept;
                            $kdprogram=$rowp2->kdprogram;
                            $kdgiat=$rowp2->kdgiat;
                            $kdoutput=$rowp2->kdnewoutput;
                            $nmoutput='';
                            $satuan='';  
                            $harga=$rowp2->pagu; 
                            $ket=$rowp2->ket;                             
                            
                            	$sql = "insert into d_new_output1(kddept,kdprogram,kdgiat,kdoutput,nmoutput,satuan,harga,jenis,inde,durasi,thnawal,thnakhir,lama,ket) 
                                        values('$skpd','$kdprogram','$kdgiat','$kdoutput','$nmoutput','$satuan','$harga','1','1','1','2015','2019','4','$ket')";
                                $asg = $this->db->query($sql);
                                
                              
                           }
    
                     $msg = array('pesan'=>'1');
                    echo json_encode($msg);
                    exit();
                } else {
                    $msg = array('pesan'=>'0');
                    echo json_encode($msg);
                    exit();
                }
            
        }
     
     function simpan_grouping_komponen(){
                $skpd     = $this->session->userdata('kdskpd');
                $sql = "delete from t_new_komponen where kddept='$skpd' ";
    			$asg = $this->db->query($sql);
                if ($asg){    
                    	$sql = "INSERT INTO t_new_komponen 
                                SELECT a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,a.kdoutput,b.kdkmpnen,SUM(b.jumlah) AS pagu,0 AS pagu1,0 AS pagu2,0 AS pagu3,0 AS pagu4,a.ket,'1' AS jns FROM t_new_output a 
                                INNER JOIN d_item b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdoutput 
                                GROUP BY a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,a.kdoutput,b.kdkmpnen,a.ket";
                        $asg = $this->db->query($sql);
                                
                
                           
                 $msg = array('pesan'=>'1');
                    echo json_encode($msg);
                    exit();
                     
                } else {
                    $msg = array('pesan'=>'0');
                    echo json_encode($msg);
                    exit();
                }
            
        }
     
     function simpan_grouping_lokasi(){
                $skpd     = $this->session->userdata('kdskpd');
                $sql = "delete from d_item_lokasi where kddept='$skpd' ";
    			$asg = $this->db->query($sql);
                if ($asg){    
                    	$sql = "INSERT INTO d_item_lokasi
                                SELECT a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,'' AS kdoutput,b.kdlokasi,SUM(b.jumlah)AS pagu,'' AS vol,'' AS vol1,'' AS vol2,'' AS vol3,'' AS vol4 FROM t_new_output a 
                                INNER JOIN d_item b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdoutput 
                                GROUP BY a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,b.kdlokasi 
                                ";
                        $asg = $this->db->query($sql);
//SELECT a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,a.kdoutput,b.kdlokasi,SUM(b.jumlah)AS pagu,'1' AS vol,'1' AS vol1,'1' AS vol2,'1' AS vol3,'1' AS vol4 FROM t_new_output a 
//                                INNER JOIN d_item b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdoutput 
//                                GROUP BY a.kddept,a.kdprogram,a.kdgiat,a.kdnewoutput,a.kdoutput,b.kdlokasi                                
                
                           
                 $msg = array('pesan'=>'1');
                    echo json_encode($msg);
                    exit();
                     
                } else {
                    $msg = array('pesan'=>'0');
                    echo json_encode($msg);
                    exit();
                }
            
        }
        
     function simpan_proyeksi(){
                $skpd     = $this->session->userdata('kdskpd');
                
                $sql3=$this->db->query("SELECT * from proyeksi");
                $tmp = $sql3->result_array();
                $thn1 = $tmp[0]['thn1']/100;
                $thn2 = $tmp[0]['thn2']/100;
                $thn3 = $tmp[0]['thn3']/100;
                $thn4 = $tmp[0]['thn4']/100;
                //print_r($thn1);
                $sql = "delete from d_item_output where kddept='$skpd' ";
    			$asg = $this->db->query($sql);
                if ($asg){
    			$sql2="SELECT a.*,b.nmoutput as nama,b.sat as sat FROM d_new_output1 a 
                        INNER JOIN t_new_output b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdnewoutput AND a.ket=b.ket ";
                     $sqlp2=$this->db->query($sql2);
                     foreach ($sqlp2->result() as $rowp2)
                        {
                           
                            $kddept=$rowp2->kddept;
                            $kdprogram=$rowp2->kdprogram;
                            $kdgiat=$rowp2->kdgiat;
                            $kdoutput=$rowp2->kdoutput;
                            $nmoutput=$rowp2->nama;
                            $satuan=$rowp2->sat; 
                            $vol= $rowp2->vol;
                            $harga=$rowp2->hargaunit;
                            $jenis=$rowp2->jenis; 
                            $inde=$rowp2->inde;
                            $durasi=$rowp2->durasi;
                            $thnawal=$rowp2->thnawal;
                            $thnakhir=$rowp2->thnakhir;
                            $lama=$rowp2->lama;
                            $t2015=$rowp2->t2015;
                            $t2016=$rowp2->t2016;
                            $t2017=$rowp2->t2017;
                            $t2018=$rowp2->t2018;
                            $t2019=$rowp2->t2019;
                            if ($inde=='1'){                            
                                $harga1=$thn1*$harga;
                                $proyeksi1=$harga+$harga1;
                                $harga2=$thn2*$proyeksi1;
                                $proyeksi2=$proyeksi1+$harga2;
                                $harga3=$thn3*$proyeksi2;
                                $proyeksi3=$proyeksi2+$harga3;
                                $harga4=$thn4*$proyeksi3;  
                                $proyeksi4=$proyeksi3+$harga4;
                            }else{
                                $proyeksi1=$harga;
                                $proyeksi2=$harga;
                                $proyeksi3=$harga; 
                                $proyeksi4=$harga;
                            }
                            
                            
                            if ($t2015=='1'){
                                $proy1=$harga;
                                $vol1=$vol;
                            }else{
                                $proy1=0;
                                $vol1=0;
                            }
                            
                            if ($t2016=='1'){
                                $proy2=$proyeksi1;
                                $vol2=1;
                            }else{
                                $proy2=0;
                                $vol2=0;
                            }
                            
                            if ($t2017=='1'){
                                $proy3=$proyeksi2;
                                $vol3=1;
                            }else{
                                $proy3=0;
                                $vol3=0;
                            }
                            
                            if ($t2018=='1'){
                                $proy4=$proyeksi3;
                                $vol4=1;
                            }else{
                                $proy4=0;
                                $vol4=0;
                            }
                            
                            if ($t2019=='1'){
                                $proy5=$proyeksi4;
                                $vol5=1;
                            }else{
                                $proy5=0;
                                $vol5=0;
                            }
                            
                           
                            
                            
                            
                            	$sql = "insert into d_item_output(kddept,kdprogram,kdgiat,kdoutput,nmoutput,satuan,jenis,inde,durasi,thnawal,thnakhir,lama,vol,vol1,vol2,vol3,vol4,harga,harga1,harga2,harga3,harga4,t2015,t2016,t2017,t2018,t2019) 
                                        values('$skpd','$kdprogram','$kdgiat','$kdoutput','$nmoutput','$satuan','$jenis','$inde','$durasi','$thnawal','$thnakhir','$lama','$vol1','$vol2','$vol3','$vol4','$vol5','$proy1','$proy2','$proy3','$proy4','$proy5','$t2015','$t2016','$t2017','$t2018','$t2019')";
                                $asg = $this->db->query($sql);
                                
                              
                           }
    
                    $msg = array('pesan'=>'1');
                    echo json_encode($msg);
                    exit();
                } else {
                    $msg = array('pesan'=>'0');
                    echo json_encode($msg);
                    exit();
                }
            
        }       
    
    function tsimpan(){
        
        $dept = $this->input->post('dept');
        $prog = $this->input->post('prog');
        $giat  = $this->input->post('giat');
        $output  = $this->input->post('output');
        $lokasi = $this->input->post('lokasi');
        $lckolom = $this->input->post('kolom');
        $lcnilai = $this->input->post('nilai');
        
        //$sql = "insert into d_item_lokasi $lckolom values $lcnilai";
//        $asg = $this->db->query($sql);
        //(kddept,kdprogram,kdgiat,kdoutput,lokasi,vol,vol1,vol2,vol3,vol4)/('033','01','2379','001','01','4','2','4','4','4')
        $query_del = $this->db->query("delete from d_item_lokasi where kddept='$dept' and kdprogram='$prog' and kdgiat='$giat' and kdnewoutput='$output' and lokasi='$lokasi' ");
        $sql = "insert into d_item_lokasi $lckolom values $lcnilai";
        $asg = $this->db->query($sql);        
        
         if($asg){
                echo '1';
            }else{
                echo '0';
            }
        
    }
    	
    function hapus_output(){
        $skpd = $this->input->post('skpd');
        $prog = $this->input->post('prog');
        $giat = $this->input->post('giat');
        $outout = $this->input->post('outout');
        $msg = array();
        $sql = "delete from d_new_output where kddept='$skpd' and kdprogram='$prog' and kdgiat='$giat' and kdoutput='$output'";
        $asg = $this->db->query($sql);
    
    	
    
    	if ($asg){
            $msg = array('pesan'=>'1');
            echo json_encode($msg);
        } else {
            $msg = array('pesan'=>'0');
            echo json_encode($msg);
            
        }
    }
    
    function select_output($cskpd='',$cprog='',$cgiat='') {
            
    	$sql = "select * from d_item_output
                    WHERE kddept='$cskpd' and kdprogram='$cprog' AND kdgiat='$cgiat' order by kdoutput";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdoutput' => $resulte['kdoutput'],  
                            'nmoutput' => $resulte['nmoutput'],  
                            'satuan' => $resulte['satuan'],
                            'vol' => $resulte['vol'],
                            'vol1' => $resulte['vol1'],
                            'vol2' => $resulte['vol2'],
                            'vol3' => $resulte['vol3'],
                            'vol4' => $resulte['vol4'],
                            'harga'=> $resulte['harga'],
                            'harga1'=> $resulte['harga1'],
                            'harga2'=> $resulte['harga2'],
                            'harga3'=> $resulte['harga3'],
                            'harga4'=> $resulte['harga4']                       
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
        function select_output1($cskpd='',$cprog='',$cgiat='') {
            
    	$sql = "SELECT a.kddept,a.kdprogram,a.kdgiat,a.kdoutput,b.nmoutput,b.sat,a.harga,a.vol,a.hargaunit,a.jenis,a.inde,a.durasi,a.thnawal,a.thnakhir,a.lama,a.t2015,a.t2016,a.t2017,a.t2018,a.t2019 FROM d_new_output1 a
                INNER JOIN t_new_output b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdnewoutput AND a.ket=b.ket
                WHERE a.kddept='$cskpd' and a.kdprogram='$cprog' AND a.kdgiat='$cgiat' order by a.kdoutput";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdoutput' => $resulte['kdoutput'],  
                            'nmoutput' => $resulte['nmoutput'],  
                            'satuan' => $resulte['sat'],
                            'harga1' => $resulte['harga'],
                            'harga' => number_format($resulte['harga']),
                            'vol' => $resulte['vol'],
                            'hargaunit1' => $resulte['hargaunit'],
                            'hargaunit' => number_format($resulte['hargaunit']),
                            'jenis' => $resulte['jenis'],
                            'inde' => $resulte['inde'],
                            'durasi' => $resulte['durasi'],
                            'thnawal' => $resulte['thnawal'],
                            'thnakhir' => $resulte['thnakhir'],
                            't2015' => $resulte['t2015'],
                            't2016' => $resulte['t2016'],
                            't2017' => $resulte['t2017'],
                            't2018' => $resulte['t2018'],
                            't2019' => $resulte['t2019']                        
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
        
        function select_komponen($cskpd='',$cprog='',$cgiat='',$coutput='') {
            
    	$sql = "SELECT * FROM t_new_komponen  
                WHERE kddept='$cskpd' and kdprogram='$cprog' AND kdgiat='$cgiat' AND kdnewoutput='$coutput' order by kdkmpnen";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdkmpnen' => $resulte['kdkmpnen'],  
                            'urkmpnen' => $resulte['nmkmpnen'], 
                            'pagu' => $resulte['pagu'],
                            'pagu1' => number_format($resulte['pagu']),
                            'pagu2' => number_format($resulte['pagu1']),
                            'pagu3' => number_format($resulte['pagu2']),
                            'pagu4' => number_format($resulte['pagu3']),
                            'pagu5' => number_format($resulte['pagu4']),
                            'jns' => $resulte['jns']                 
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
        function select_lokasi($cskpd='',$cprog='',$cgiat='',$coutput='') {
            
    	$sql = "SELECT a.kdlokasi,a.kdoutput,b.nmlokasi as nama,a.vol,a.vol1,a.vol2,a.vol3,a.vol4 FROM d_item_output_lokasi a INNER JOIN t_lokasi b ON a.kdlokasi=b.kdlokasi
                WHERE a.kddept='$cskpd' and a.kdprogram='$cprog' AND a.kdgiat='$cgiat' AND a.kdoutput='$coutput' order by a.kdlokasi";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'kdlokasi' => $resulte['kdlokasi'],  
                            'nmlokasi' => $resulte['nama'], 
                            'output' => $resulte['kdoutput'],
                            'vol1' => $resulte['vol'],
                            'vol2' => $resulte['vol1'],
                            'vol3' => $resulte['vol2'],
                            'vol4' => $resulte['vol3'],
                            'vol5' => $resulte['vol4']                    
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
        function cetak_outputvs()
    	{
    		
            $data['page_title']= 'BAPPENAS';
            $this->template->set('title', 'BAPPENAS');          
            $this->template->load('template','anggaran/rka/cetakvs',$data) ; 
            //$this->load->view('anggaran/rka/tambah_rka',$data) ;
       }
        function cetak_baseline()
    	{
    		
            $data['page_title']= 'BAPPENAS';
            $this->template->set('title', 'BAPPENAS');          
            $this->template->load('template','anggaran/rka/cetak',$data) ; 
            //$this->load->view('anggaran/rka/tambah_rka',$data) ;
       }
       
       function cetak_renstra()
    	{
    		
            $data['page_title']= 'BAPPENAS';
            $this->template->set('title', 'BAPPENAS');          
            $this->template->load('template','anggaran/rka/cetakrenstra',$data) ; 
            //$this->load->view('anggaran/rka/tambah_rka',$data) ;
       }
       
       function cetak_renstra_lokasi()
    	{
    		
            $data['page_title']= 'BAPPENAS';
            $this->template->set('title', 'BAPPENAS');          
            $this->template->load('template','anggaran/rka/cetakrenstra_lokasi',$data) ; 
            //$this->load->view('anggaran/rka/tambah_rka',$data) ;
       }
       
       function cetak_renstra_komponen()
    	{
    		
            $data['page_title']= 'BAPPENAS';
            $this->template->set('title', 'BAPPENAS');          
            $this->template->load('template','anggaran/rka/cetakrenstra_komponen',$data) ; 
            //$this->load->view('anggaran/rka/tambah_rka',$data) ;
       }
       
        function preview_baseline($ct='1'){
            
            $kd_skpd = $this->session->userdata('kdskpd');
            $thn_ang = $this->session->userdata('pcThang');
            $sqldns="select * from t_dept   WHERE kddept='$kd_skpd'";
                 $sqlskpd=$this->db->query($sqldns);
                 foreach ($sqlskpd->result() as $rowdns)
                {
                   
                    $kd_dept = $rowdns->kddept;
                    $nm_dept  = $rowdns->nmdept;
                }
            $cRet='';

                    $cRet .="<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
                                <tr>
                                     <td align=\"center\"><strong> ALOKASI BASELINE $thn_ang </strong></td>
                                </tr> 
                                <tr>
                                     <td align=\"center\"><strong>$kd_dept:$nm_dept</strong></td>                         
                                </tr>
                                                   
                                
                                <tr>
                                     <td align=\"center\">&nbsp;</td>
                                </tr>
                              </table>";
                            
                    $cRet .= "<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
                                 <thead>                       
                                    
             		                    
                                        <td width=\"30%\" bgcolor=\"#CCCCCC\" align=\"center\">Program</td>
                                        <td width=\"25%\" bgcolor=\"#CCCCCC\" align=\"center\">Kegiatan</td>
                                        <td width=\"25%\" bgcolor=\"#CCCCCC\" align=\"center\">Sasaran Kegiatan(Output)</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\">Satuan</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\">Alokasi (Juta rupiah)</td>
                                    </tr>    
                                 </thead>
                                    ";
                             
                                 $sql="SELECT a.kdprogram,b.nmprogram ,SUM(hargaunit) as nilai FROM d_new_output1 a INNER JOIN t_program b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram
                                        WHERE a.kddept='$kd_skpd' GROUP BY a.kdprogram,b.nmprogram ";
                                 $sqlp=$this->db->query($sql);
                                 foreach ($sqlp->result() as $rowp)
                                    {
                                       
                                        $kdprog=$rowp->kdprogram;
                                        $nama=$rowp->nmprogram;
                                        $nilai1=$rowp->nilai;
                                        $nilai2=$nilai1/1000000;                    
                                        $nilai= number_format($nilai2,2);   
                                         $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"30%\">$kdprog-$nama</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"25%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"25%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$nilai</td></tr>
                                                         </tr>";
                                                         
                                            $sql1="SELECT a.kdgiat,b.nmgiat ,SUM(hargaunit)as nilai FROM d_new_output1 a INNER JOIN t_giat b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat
                                                  WHERE a.kddept='$kd_skpd' AND a.kdprogram='$kdprog' GROUP BY a.kdgiat,b.nmgiat ";
                                                 $sqlp1=$this->db->query($sql1);
                                                 foreach ($sqlp1->result() as $rowp1)
                                                    {
                                                       
                                                        $kdgiat=$rowp1->kdgiat;
                                                        $namagiat=$rowp1->nmgiat;
                                                        $nilaigiat1=$rowp1->nilai;
                                                        $nilaigiat2=$nilaigiat1/1000000;                      
                                                        $nilaigiat= number_format($nilaigiat2,2);   
                                                         $cRet    .= " <tr>                                    
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"30%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"25%\">$kdprog.$kdgiat-$namagiat</td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"25%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$nilaigiat</td></tr>
                                                                         </tr>";
                                                                         
                                                         $sql2="SELECT a.kdoutput,b.nmoutput,b.sat,hargaunit as nilai FROM d_new_output1 a INNER JOIN t_new_output b  ON  a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat and a.kdoutput=b.kdnewoutput and a.ket=b.ket
                                                                    WHERE a.kddept='$kd_skpd' and a.kdprogram='$kdprog' AND a.kdgiat='$kdgiat' ";
                                                                 $sqlp2=$this->db->query($sql2);
                                                                 foreach ($sqlp2->result() as $rowp2)
                                                                    {
                                                                       
                                                                        $kdoutput=$rowp2->kdoutput;
                                                                        $nnmoutput=$rowp2->nmoutput;
                                                                        $satuan=$rowp2->sat;
                                                                        $harga1=$rowp2->nilai;
                                                                        $harga2=$harga1/1000000;      
                                                                        $harga =  number_format($harga2,2);        
                                                                         $cRet    .= " <tr>                                    
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"30%\"></td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"25%\"></td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"25%\">$kdprog.$kdgiat.$kdoutput-$nnmoutput</td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$harga</td></tr>
                                                                                         </tr>";
                                                                       }
                                                }
                                    
                                            
                                       }
                                $cRet .=       " </table>";
        
        
        $data['prev']= $cRet;    
        switch($ct) {       
        case 1;
            echo($cRet);
            //$this->template->load('template','master/kegiatan/cetak1',$data);
        break;
        case 2;
            $this->_mpdf('',$cRet,10,10,10,'1');
        break;
        case 3;        
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename= $judul.xls");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        case 4;     
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-word");
            header("Content-Disposition: attachment; filename= $judul.doc");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        } 
        
                
    }
    
    function preview_outputvs($ct='1'){
            
            $kd_skpd = $this->session->userdata('kdskpd');
            $sqldns="select * from t_dept   WHERE kddept='$kd_skpd'";
                 $sqlskpd=$this->db->query($sqldns);
                 foreach ($sqlskpd->result() as $rowdns)
                {
                   
                    $kd_dept = $rowdns->kddept;
                    $nm_dept  = $rowdns->nmdept;
                }
            
            $cRet='';

                     $cRet .="<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
                                <tr>
                                     <td align=\"center\"><strong>$kd_dept:$nm_dept</strong></td>                         
                                </tr>
                                <tr>
                                     <td align=\"center\"><strong>PERSANDINGAN OUTPUT RKA-KL  OUTPUT RENSTRA(Dalam Juta Rupiah) </strong></td>
                                </tr>                    
                                
                                <tr>
                                     <td align=\"center\">&nbsp;</td>
                                </tr>
                              </table>";
                            
                    $cRet .= "<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
                                 <thead>                       
                                    
             		                    
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\">Program</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\">Kegiatan</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\">Output Baru</td>
                                        <td width=\"5%\" bgcolor=\"#CCCCCC\" align=\"center\">Satuan </td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\">Output Lama</td>
                                        <td width=\"5%\" bgcolor=\"#CCCCCC\" align=\"center\">Satuan</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\">harga</td>
                                        
                                    </tr>    
                                 </thead>
                                    ";
                             
                                 $sql="SELECT a.kdprogram,b.nmprogram ,SUM(harga) as nilai FROM d_new_output1 a INNER JOIN t_program b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram
                                        WHERE a.kddept='$kd_skpd' GROUP BY a.kdprogram,b.nmprogram ";
                                 $sqlp=$this->db->query($sql);
                                 foreach ($sqlp->result() as $rowp)
                                    {
                                       
                                        $kdprog=$rowp->kdprogram;
                                        $nama=$rowp->nmprogram;
                                        $nilai1=$rowp->nilai;
                                        $nilai2=$nilai1/1000000;                    
                                        $nilai= number_format($nilai2,2);   
                                         $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\">$kdprog-$nama</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$nilai</td></tr>
                                                         </tr>";
                                                         
                                            $sql1="SELECT a.kdgiat,b.nmgiat ,SUM(harga)as nilai FROM d_new_output1 a INNER JOIN t_giat b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat
                                                  WHERE a.kddept='$kd_skpd' AND a.kdprogram='$kdprog' GROUP BY a.kdgiat,b.nmgiat ";
                                                 $sqlp1=$this->db->query($sql1);
                                                 foreach ($sqlp1->result() as $rowp1)
                                                    {
                                                       
                                                        $kdgiat=$rowp1->kdgiat;
                                                        $namagiat=$rowp1->nmgiat;
                                                        $nilaigiat1=$rowp->nilai;
                                                        $nilaigiat2=$nilaigiat1/1000000;                     
                                                        $nilaigiat= number_format($nilaigiat2,2);   
                                                         $cRet    .= " <tr>                                    
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\">$kdgiat-$namagiat</td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$nilaigiat</td></tr>
                                                                         </tr>";
                                                                         
                                                         $sql2="SELECT a.kdoutput,b.nmoutput,b.sat,harga as nilai FROM d_new_output1 a INNER JOIN t_new_output b  ON  a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat and a.kdoutput=b.kdnewoutput and a.ket=b.ket
                                                                    WHERE a.kddept='$kd_skpd' and a.kdprogram='$kdprog' AND a.kdgiat='$kdgiat' ";
                                                                 $sqlp2=$this->db->query($sql2);
                                                                 foreach ($sqlp2->result() as $rowp2)
                                                                    {
                                                                       
                                                                        $kdoutputnew=$rowp2->kdoutput;
                                                                        $kdsatnew=$rowp2->sat;
                                                                        $nnmoutputnew=$rowp2->nmoutput;
                                                                        $nilainewoutput1=$rowp2->nilai;
                                                                        $nilainewoutput2=$nilainewoutput1/1000000;                
                                                                        $nilainewoutput= number_format($nilainewoutput2,2);   
                                                                         $cRet    .= " <tr>                                    
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\">$kdoutputnew-$nnmoutputnew</td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\" >$kdsatnew</td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\" align=\"right\"></td>
                                                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$nilainewoutput</td></tr>
                                                                                         </tr>";
                                                                         $sql3="SELECT kdoutput,nmoutput,satlama,pagu as nilai FROM t_new_output 
                                                                                WHERE kddept='$kd_skpd' and kdprogram='$kdprog' AND kdgiat='$kdgiat' and kdnewoutput='$kdoutputnew' and ket <> '4' order by kdoutput ";
                                                                             $sqlp3=$this->db->query($sql3);
                                                                             foreach ($sqlp3->result() as $rowp3)
                                                                                {
                                                                                   
                                                                                    $kdoutput=$rowp3->kdoutput;
                                                                                    $nnmoutput=$rowp3->nmoutput;
                                                                                    $satuan=$rowp3->satlama;
                                                                                    $harga1=$rowp3->nilai;
                                                                                    $harga2=$harga1/1000000;                 
                                                                                    $harga= number_format($harga2,2);   
                                                                                     $cRet    .= " <tr>                                    
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\" align=\"right\"></td>
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\">$kdoutput-$nnmoutput</td>
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\" align=\"right\">$satuan</td>
                                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\" align=\"right\">$harga</td></tr>
                                                                                                     </tr>";
                                                                                   }
                                                                       }
                                                }
                                    
                                           
                                       }
                                 $cRet .=       " </table>";
        
        
        $data['prev']= $cRet;    
        switch($ct) {       
        case 1;
            echo($cRet);
            //$this->template->load('template','master/kegiatan/cetak1',$data);
        break;
        case 2;
            $this->_mpdf('',$cRet,10,10,10,'1');
        break;
        case 3;        
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename= $judul.xls");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        case 4;     
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-word");
            header("Content-Disposition: attachment; filename= $judul.doc");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        } 
        
                
    }
    
    
    function preview_renstra($ct='1'){
            
            $kd_skpd = $this->session->userdata('kdskpd');
            $thn_ang = $this->session->userdata('pcThang');
            $sqldns="select * from t_dept   WHERE kddept='$kd_skpd'";
                 $sqlskpd=$this->db->query($sqldns);
                 foreach ($sqlskpd->result() as $rowdns)
                {
                   
                    $kd_dept = $rowdns->kddept;
                    $nm_dept  = $rowdns->nmdept;
                }
            
            $thn_ang_2= $thn_ang+1;
            $thn_ang_3= $thn_ang+2;
            $thn_ang_4= $thn_ang+3;
            $thn_ang_5= $thn_ang+4;
            $cRet='';
                     $cRet .="<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
                                <tr>
                                     <td align=\"center\"><strong>ALOKASI 2016-2019</strong></td>                         
                                </tr>
                                <tr>
                                     <td align=\"center\"><strong>$kd_dept:$nm_dept</strong></td>                         
                                </tr>
                                                  
                                
                                <tr>
                                     <td align=\"center\">&nbsp;</td>
                                </tr>
                              </table>";   
                    
                            
                    $cRet .= "<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
                                 <thead>                       
                                    
             		                  <tr>  
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Program</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Kegiatan</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Sasaran Kegiatan(Output)</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\" >Volume Output</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\">Satuan</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\">Alokasi(Dalam Juta Rupiah)</td>
                                      </tr> 
                                      
                                      <tr>  
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                      </tr>   
                                 </thead>
                                    ";
                             
                                 $sql="SELECT a.kdprogram,b.nmprogram,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4  FROM d_item_output a INNER JOIN t_program b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram
                                        WHERE a.kddept='$kd_skpd' GROUP BY a.kdprogram,b.nmprogram ";
                                 $sqlp=$this->db->query($sql);
                                 foreach ($sqlp->result() as $rowp)
                                    {
                                       
                                        $kdprog=$rowp->kdprogram;
                                        $nama=$rowp->nmprogram;
                                        $total1 =  number_format($rowp->total/1000000,2);
                                        $total2 =  number_format($rowp->total1/1000000,2);
                                        $total3 =  number_format($rowp->total2/1000000,2);
                                        $total4 =  number_format($rowp->total3/1000000,2);
                                        $total5 =  number_format($rowp->total4/1000000,2);                  
                                         $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\">$kdprog-$nama</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total5</td>
                                                         </tr>
                                                         ";
                                                         
                                            $sql1="SELECT a.kdgiat,b.nmgiat,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4 FROM d_item_output a INNER JOIN t_giat b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat
                                                  WHERE a.kddept='$kd_skpd' AND a.kdprogram='$kdprog' GROUP BY a.kdgiat,b.nmgiat ";
                                                 $sqlp1=$this->db->query($sql1);
                                                 foreach ($sqlp1->result() as $rowp1)
                                                    {
                                                       
                                                        $kdgiat=$rowp1->kdgiat;
                                                        $nmgiat=$rowp1->nmgiat;
                                                        $tot1 =  number_format($rowp1->total/1000000,2);
                                                        $tot2 =  number_format($rowp1->total1/1000000,2);
                                                        $tot3 =  number_format($rowp1->total2/1000000,2);
                                                        $tot4 =  number_format($rowp1->total3/1000000,2);
                                                        $tot5 =  number_format($rowp1->total4/1000000,2); 
                                                                               
                                                        $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat -$nmgiat</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot5</td>
                                                         </tr>
                                                         ";
                                                                         
                                                         $sql2="SELECT * FROM d_item_output 
                                                                    WHERE kddept='$kd_skpd' and kdprogram='$kdprog' AND kdgiat='$kdgiat'  ";
                                                                 $sqlp2=$this->db->query($sql2);
                                                                 foreach ($sqlp2->result() as $rowp2)
                                                                    {
                                                                       
                                                                        $kdoutput=$rowp2->kdoutput;
                                                                        $nnmoutput=$rowp2->nmoutput;
                                                                        $satuan=$rowp2->satuan;
                                                                        $vol1=$rowp2->vol;
                                                                        if($vol1==0){
                                                                           $vol1=''; 
                                                                        }
                                                                        $vol2=$rowp2->vol1;
                                                                        if($vol2==0){
                                                                           $vol2=''; 
                                                                        }
                                                                        $vol3=$rowp2->vol2;
                                                                        if($vol3==0){
                                                                           $vol3=''; 
                                                                        }
                                                                        $vol4=$rowp2->vol3;
                                                                        if($vol4==0){
                                                                           $vol4=''; 
                                                                        }
                                                                        $vol5=$rowp2->vol4;
                                                                        if($vol5==0){
                                                                           $vol5=''; 
                                                                        }
                                                                        $hrg1 =  $rowp2->harga; 
                                                                        $hrg2 =  $rowp2->harga1;
                                                                        $hrg3 =  $rowp2->harga2;
                                                                        $hrg4 =  $rowp2->harga3;
                                                                        $hrg5 =  $rowp2->harga4;  
                                                                        $nilai1 =  $hrg1*$vol1; 
                                                                        $nilai2 =  $hrg2*$vol2;
                                                                        $nilai3 =  $hrg3*$vol3;
                                                                        $nilai4 =  $hrg4*$vol4;
                                                                        $nilai5 =  $hrg5*$vol5; 
                                                                        $harga1 =  number_format($nilai1/1000000,2);
                                                                        if($harga1==0){
                                                                           $harga1=''; 
                                                                        } 
                                                                        $harga2 =  number_format($nilai2/1000000,2);
                                                                        if($harga2==0){
                                                                           $harga2=''; 
                                                                        }
                                                                        $harga3 =  number_format($nilai3/1000000,2);
                                                                        if($harga3==0){
                                                                           $harga3=''; 
                                                                        }
                                                                        $harga4 =  number_format($nilai4/1000000,2);
                                                                        if($harga4==0){
                                                                           $harga4=''; 
                                                                        }
                                                                        $harga5 =  number_format($nilai5/1000000,2);
                                                                        if($harga5==0){
                                                                           $harga5=''; 
                                                                        }       
                                                                         $cRet    .= " <tr>                                    
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat.$kdoutput-$nnmoutput</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol5</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga5</td>
                                                                                     </tr>
                                                                                     ";
                                                                       }
                                                }
                                    
                                            
                                       }
                                $cRet .=       " </table>";
        
        
        $data['prev']= $cRet;    
        switch($ct) {       
        case 1;
            echo($cRet);
            //$this->template->load('template','master/kegiatan/cetak1',$data);
        break;
        case 2;
            $this->_mpdf('',$cRet,10,10,10,'1');
        break;
        case 3;        
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename= $judul.xls");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        case 4;     
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-word");
            header("Content-Disposition: attachment; filename= $judul.doc");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        } 
        
                
    }
    
    
        
    function preview_renstra_lokasi($ct='1'){
            
            $kd_skpd = $this->session->userdata('kdskpd');
            $thn_ang = $this->session->userdata('pcThang');
            $sqldns="select * from t_dept   WHERE kddept='$kd_skpd'";
                 $sqlskpd=$this->db->query($sqldns);
                 foreach ($sqlskpd->result() as $rowdns)
                {
                   
                    $kd_dept = $rowdns->kddept;
                    $nm_dept  = $rowdns->nmdept;
                }
            
            $thn_ang_2= $thn_ang+1;
            $thn_ang_3= $thn_ang+2;
            $thn_ang_4= $thn_ang+3;
            $thn_ang_5= $thn_ang+4;
            $cRet='';
                     $cRet .="<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
                                <tr>
                                     <td align=\"center\"><strong>ALOKASI BASELINE 2016-2019</strong></td>                         
                                </tr>
                                <tr>
                                     <td align=\"center\"><strong>$kd_dept:$nm_dept</strong></td>                         
                                </tr>
                                                  
                                
                                <tr>
                                     <td align=\"center\">&nbsp;</td>
                                </tr>
                              </table>";   
                    
                            
                    $cRet .= "<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
                                 <thead>                       
                                    
             		                  <tr>  
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Program</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Kegiatan</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Sasaran Kegiatan(Output)</td>
                                        <td width=\"5%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Lokasi</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\" >Volume Output</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\">Satuan</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\">Alokasi(Dalam Juta Rupiah)</td>
                                      </tr> 
                                      
                                      <tr>  
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                      </tr>   
                                 </thead>
                                    ";
                             
                                 $sql="SELECT a.kdprogram,b.nmprogram,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4  FROM d_item_output a INNER JOIN t_program b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram
                                        WHERE a.kddept='$kd_skpd' GROUP BY a.kdprogram,b.nmprogram ";
                                 $sqlp=$this->db->query($sql);
                                 foreach ($sqlp->result() as $rowp)
                                    {
                                       
                                        $kdprog=$rowp->kdprogram;
                                        $nama=$rowp->nmprogram;
                                        $total1 =  number_format($rowp->total/1000000,2);
                                        $total2 =  number_format($rowp->total1/1000000,2);
                                        $total3 =  number_format($rowp->total2/1000000,2);
                                        $total4 =  number_format($rowp->total3/1000000,2);
                                        $total5 =  number_format($rowp->total4/1000000,2);                  
                                         $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog-$nama</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total5</td>
                                                         </tr>
                                                         ";
                                                         
                                            $sql1="SELECT a.kdgiat,b.nmgiat,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4 FROM d_item_output a INNER JOIN t_giat b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat
                                                  WHERE a.kddept='$kd_skpd' AND a.kdprogram='$kdprog' GROUP BY a.kdgiat,b.nmgiat ";
                                                 $sqlp1=$this->db->query($sql1);
                                                 foreach ($sqlp1->result() as $rowp1)
                                                    {
                                                       
                                                        $kdgiat=$rowp1->kdgiat;
                                                        $nmgiat=$rowp1->nmgiat;
                                                        $tot1 =  number_format($rowp1->total/1000000,2);
                                                        $tot2 =  number_format($rowp1->total1/1000000,2);
                                                        $tot3 =  number_format($rowp1->total2/1000000,2);
                                                        $tot4 =  number_format($rowp1->total3/1000000,2);
                                                        $tot5 =  number_format($rowp1->total4/1000000,2); 
                                                                               
                                                        $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat -$nmgiat</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot5</td>
                                                         </tr>
                                                         ";
                                                                         
                                                         $sql2="SELECT * FROM d_item_output 
                                                                WHERE kddept='$kd_skpd' and kdprogram='$kdprog' AND kdgiat='$kdgiat'  ";
                                                                 $sqlp2=$this->db->query($sql2);
                                                                 foreach ($sqlp2->result() as $rowp2)
                                                                    {
                                                                       
                                                                        $kdoutput=$rowp2->kdoutput;
                                                                        $nnmoutput=$rowp2->nmoutput;
                                                                        $satuan=$rowp2->satuan;
                                                                        $vol1=$rowp2->vol;
                                                                        if($vol1==0){
                                                                           $vol1=''; 
                                                                        }
                                                                        $vol2=$rowp2->vol1;
                                                                        if($vol2==0){
                                                                           $vol2=''; 
                                                                        }
                                                                        $vol3=$rowp2->vol2;
                                                                        if($vol3==0){
                                                                           $vol3=''; 
                                                                        }
                                                                        $vol4=$rowp2->vol3;
                                                                        if($vol4==0){
                                                                           $vol4=''; 
                                                                        }
                                                                        $vol5=$rowp2->vol4;
                                                                        if($vol5==0){
                                                                           $vol5=''; 
                                                                        }
                                                                        $hrg1 =  $rowp2->harga; 
                                                                        $hrg2 =  $rowp2->harga1;
                                                                        $hrg3 =  $rowp2->harga2;
                                                                        $hrg4 =  $rowp2->harga3;
                                                                        $hrg5 =  $rowp2->harga4;  
                                                                        $nilai1 =  $hrg1*$vol1; 
                                                                        $nilai2 =  $hrg2*$vol2;
                                                                        $nilai3 =  $hrg3*$vol3;
                                                                        $nilai4 =  $hrg4*$vol4;
                                                                        $nilai5 =  $hrg5*$vol5; 
                                                                        $harga1 =  number_format($nilai1/1000000,2);
                                                                        if($harga1==0){
                                                                           $harga1=''; 
                                                                        } 
                                                                        $harga2 =  number_format($nilai2/1000000,2);
                                                                        if($harga2==0){
                                                                           $harga2=''; 
                                                                        }
                                                                        $harga3 =  number_format($nilai3/1000000,2);
                                                                        if($harga3==0){
                                                                           $harga3=''; 
                                                                        }
                                                                        $harga4 =  number_format($nilai4/1000000,2);
                                                                        if($harga4==0){
                                                                           $harga4=''; 
                                                                        }
                                                                        $harga5 =  number_format($nilai5/1000000,2);
                                                                        if($harga5==0){
                                                                           $harga5=''; 
                                                                        }             
                                                                         $cRet    .= " <tr>                                    
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat.$kdoutput-$nnmoutput</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol5</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga5</td>
                                                                                     </tr>
                                                                                     ";
                                                                                     $sql3="SELECT a.kdoutput,a.nmoutput,a.satuan,a.harga,a.harga1,a.harga2,a.harga3,a.harga4,b.lokasi,b.vol,b.vol1,b.vol2,b.vol3,b.vol4 FROM d_item_output a
                                                                                            INNER JOIN d_item_lokasi b  ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat AND a.kdoutput=b.kdnewoutput 
                                                                                            WHERE a.kddept='$kd_skpd' and a.kdprogram='$kdprog' AND a.kdgiat='$kdgiat' and a.kdoutput='$kdoutput'  ";
                                                                                             $sqlp3=$this->db->query($sql3);
                                                                                             foreach ($sqlp3->result() as $rowp3)
                                                                                                {
                                                                                                   
                                                                                                    
                                                                                                    $satuan=$rowp3->satuan;
                                                                                                    $lokasi=$rowp3->lokasi;
                                                                                                    $vol1=$rowp3->vol;
                                                                                                    if($vol1==0){
                                                                                                       $vol1=''; 
                                                                                                    }
                                                                                                    $vol2=$rowp3->vol1;
                                                                                                    if($vol2==0){
                                                                                                       $vol2=''; 
                                                                                                    }
                                                                                                    $vol3=$rowp3->vol2;
                                                                                                    if($vol3==0){
                                                                                                       $vol3=''; 
                                                                                                    }
                                                                                                    $vol4=$rowp3->vol3;
                                                                                                    if($vol4==0){
                                                                                                       $vol4=''; 
                                                                                                    }
                                                                                                    $vol5=$rowp3->vol4;
                                                                                                    if($vol5==0){
                                                                                                       $vol5=''; 
                                                                                                    }
                                                                                                    $hrg1 =  $rowp3->harga; 
                                                                                                    $hrg2 =  $rowp3->harga1;
                                                                                                    $hrg3 =  $rowp3->harga2;
                                                                                                    $hrg4 =  $rowp3->harga3;
                                                                                                    $hrg5 =  $rowp3->harga4;  
                                                                                                    $nilai1 =  $hrg1*$vol1; 
                                                                                                    $nilai2 =  $hrg2*$vol2;
                                                                                                    $nilai3 =  $hrg3*$vol3;
                                                                                                    $nilai4 =  $hrg4*$vol4;
                                                                                                    $nilai5 =  $hrg5*$vol5; 
                                                                                                    $harga1 =  number_format($nilai1/1000000,2);
                                                                                                    if($harga1==0){
                                                                                                       $harga1=''; 
                                                                                                    } 
                                                                                                    $harga2 =  number_format($nilai2/1000000,2);
                                                                                                    if($harga2==0){
                                                                                                       $harga2=''; 
                                                                                                    }
                                                                                                    $harga3 =  number_format($nilai3/1000000,2);
                                                                                                    if($harga3==0){
                                                                                                       $harga3=''; 
                                                                                                    }
                                                                                                    $harga4 =  number_format($nilai4/1000000,2);
                                                                                                    if($harga4==0){
                                                                                                       $harga4=''; 
                                                                                                    }
                                                                                                    $harga5 =  number_format($nilai5/1000000,2);
                                                                                                    if($harga5==0){
                                                                                                       $harga5=''; 
                                                                                                    }       
                                                                                                     $cRet    .= " <tr>                                    
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\">$lokasi</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol1</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol2</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol3</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol4</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol5</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga1</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga2</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga3</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga4</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga5</td>
                                                                                                                 </tr>
                                                                                                                 ";
                                                                                                   }
                                                                       }
                                                }
                                    
                                            $cRet .=       " </table>";
                                       }
                                
        
        
        $data['prev']= $cRet;    
        switch($ct) {       
        case 1;
            echo($cRet);
            //$this->template->load('template','master/kegiatan/cetak1',$data);
        break;
        case 2;
            $this->_mpdf('',$cRet,10,10,10,'1');
        break;
        case 3;        
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename= $judul.xls");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        case 4;     
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-word");
            header("Content-Disposition: attachment; filename= $judul.doc");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        } 
        
                
    }
    
    function preview_renstra_jenis($ct='1'){
            
            $kd_skpd = $this->session->userdata('kdskpd');
            $thn_ang = $this->session->userdata('pcThang');
            $sqldns="select * from t_dept   WHERE kddept='$kd_skpd'";
                 $sqlskpd=$this->db->query($sqldns);
                 foreach ($sqlskpd->result() as $rowdns)
                {
                   
                    $kd_dept = $rowdns->kddept;
                    $nm_dept  = $rowdns->nmdept;
                }
            
            $thn_ang_2= $thn_ang+1;
            $thn_ang_3= $thn_ang+2;
            $thn_ang_4= $thn_ang+3;
            $thn_ang_5= $thn_ang+4;
            $cRet='';
                     $cRet .="<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
                                <tr>
                                     <td align=\"center\"><strong>ALOKASI BASELINE 2016-2019</strong></td>                         
                                </tr>
                                <tr>
                                     <td align=\"center\"><strong>$kd_dept:$nm_dept</strong></td>                         
                                </tr>
                                                  
                                
                                <tr>
                                     <td align=\"center\">&nbsp;</td>
                                </tr>
                              </table>";   
                    
                            
                    $cRet .= "<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
                                 <thead>                       
                                    
             		                  <tr>  
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Program</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Kegiatan</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Sasaran Kegiatan(Output)</td>
                                        <td width=\"5%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >BAK/BLK</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\">Satuan</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\">Alokasi(Dalam Juta Rupiah)</td>
                                      </tr> 
                                      
                                      <tr>  
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                      </tr>   
                                 </thead>
                                    ";
                             
                                 $sql="SELECT a.kdprogram,b.nmprogram,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4  FROM d_item_output a INNER JOIN t_program b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram
                                        WHERE a.kddept='$kd_skpd' GROUP BY a.kdprogram,b.nmprogram ";
                                 $sqlp=$this->db->query($sql);
                                 foreach ($sqlp->result() as $rowp)
                                    {
                                       
                                        $kdprog=$rowp->kdprogram;
                                        $nama=$rowp->nmprogram;
                                        $total1 =  number_format($rowp->total/1000000,2);
                                        $total2 =  number_format($rowp->total1/1000000,2);
                                        $total3 =  number_format($rowp->total2/1000000,2);
                                        $total4 =  number_format($rowp->total3/1000000,2);
                                        $total5 =  number_format($rowp->total4/1000000,2);                  
                                         $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog-$nama</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total5</td>
                                                         </tr>
                                                         ";
                                                         
                                            $sql1="SELECT a.kdgiat,b.nmgiat,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4 FROM d_item_output a INNER JOIN t_giat b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat
                                                  WHERE a.kddept='$kd_skpd' AND a.kdprogram='$kdprog' GROUP BY a.kdgiat,b.nmgiat ";
                                                 $sqlp1=$this->db->query($sql1);
                                                 foreach ($sqlp1->result() as $rowp1)
                                                    {
                                                       
                                                        $kdgiat=$rowp1->kdgiat;
                                                        $nmgiat=$rowp1->nmgiat;
                                                        $tot1 =  number_format($rowp1->total/1000000,2);
                                                        $tot2 =  number_format($rowp1->total1/1000000,2);
                                                        $tot3 =  number_format($rowp1->total2/1000000,2);
                                                        $tot4 =  number_format($rowp1->total3/1000000,2);
                                                        $tot5 =  number_format($rowp1->total4/1000000,2); 
                                                                               
                                                        $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat -$nmgiat</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot5</td>
                                                         </tr>
                                                         ";
                                                                         
                                                         $sql2="SELECT * FROM d_item_output 
                                                                WHERE kddept='$kd_skpd' and kdprogram='$kdprog' AND kdgiat='$kdgiat'  ";
                                                                 $sqlp2=$this->db->query($sql2);
                                                                 foreach ($sqlp2->result() as $rowp2)
                                                                    {
                                                                       
                                                                        $kdoutput=$rowp2->kdoutput;
                                                                        $nnmoutput=$rowp2->nmoutput;
                                                                        $satuan=$rowp2->satuan;
                                                                        $vol1=$rowp2->vol;
                                                                        if($vol1==0){
                                                                           $vol1=''; 
                                                                        }
                                                                        $vol2=$rowp2->vol1;
                                                                        if($vol2==0){
                                                                           $vol2=''; 
                                                                        }
                                                                        $vol3=$rowp2->vol2;
                                                                        if($vol3==0){
                                                                           $vol3=''; 
                                                                        }
                                                                        $vol4=$rowp2->vol3;
                                                                        if($vol4==0){
                                                                           $vol4=''; 
                                                                        }
                                                                        $vol5=$rowp2->vol4;
                                                                        if($vol5==0){
                                                                           $vol5=''; 
                                                                        }
                                                                        $hrg1 =  $rowp2->harga; 
                                                                        $hrg2 =  $rowp2->harga1;
                                                                        $hrg3 =  $rowp2->harga2;
                                                                        $hrg4 =  $rowp2->harga3;
                                                                        $hrg5 =  $rowp2->harga4;  
                                                                        $nilai1 =  $hrg1*$vol1; 
                                                                        $nilai2 =  $hrg2*$vol2;
                                                                        $nilai3 =  $hrg3*$vol3;
                                                                        $nilai4 =  $hrg4*$vol4;
                                                                        $nilai5 =  $hrg5*$vol5; 
                                                                        $harga1 =  number_format($nilai1/1000000,2);
                                                                        if($harga1==0){
                                                                           $harga1=''; 
                                                                        } 
                                                                        $harga2 =  number_format($nilai2/1000000,2);
                                                                        if($harga2==0){
                                                                           $harga2=''; 
                                                                        }
                                                                        $harga3 =  number_format($nilai3/1000000,2);
                                                                        if($harga3==0){
                                                                           $harga3=''; 
                                                                        }
                                                                        $harga4 =  number_format($nilai4/1000000,2);
                                                                        if($harga4==0){
                                                                           $harga4=''; 
                                                                        }
                                                                        $harga5 =  number_format($nilai5/1000000,2);
                                                                        if($harga5==0){
                                                                           $harga5=''; 
                                                                        }             
                                                                         $cRet    .= " <tr>                                    
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat.$kdoutput-$nnmoutput</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga5</td>
                                                                                     </tr>
                                                                                     ";
                                                                                     $sql3="SELECT kddept,kdprogram,kdgiat,kdnewoutput,jns,SUM(pagu) AS pagu,SUM(pagu1) AS pagu1,SUM(pagu2) AS pagu2,SUM(pagu3) AS pagu3,SUM(pagu4) AS pagu4 FROM t_new_komponen  
                                                                                            WHERE kddept='$kd_skpd' and kdprogram='$kdprog' AND kdgiat='$kdgiat' and kdnewoutput='$kdoutput' GROUP BY kddept,kdprogram,kdgiat,kdnewoutput,jns ";
                                                                                             $sqlp3=$this->db->query($sql3);
                                                                                             foreach ($sqlp3->result() as $rowp3)
                                                                                                {
                                                                                                   
                                                                                                    
                                                                                                    $jns=$rowp3->jns;
                                                                                                    $pagu=$rowp3->pagu;
                                                                                                    $pagu1=$rowp3->pagu1;
                                                                                                    $pagu2=$rowp3->pagu2;
                                                                                                    $pagu3=$rowp3->pagu3;
                                                                                                    $pagu4=$rowp3->pagu4;
                                                                                                    if($jns==1){
                                                                                                       $ket='(BAK)'; 
                                                                                                    }else{
                                                                                                       $ket='(BLK)';  
                                                                                                    }
                                                                                                    
                                                                                                    
                                                                                                    $harga1 =  number_format($pagu/1000000,2);
                                                                                                    if($harga1==0){
                                                                                                       $harga1=''; 
                                                                                                    }
                                                                                                    $harga2 =  number_format($pagu1/1000000,2);
                                                                                                    if($harga2==0){
                                                                                                       $harga2=''; 
                                                                                                    }
                                                                                                    $harga3 =  number_format($pagu2/1000000,2);
                                                                                                    if($harga3==0){
                                                                                                       $harga3=''; 
                                                                                                    }
                                                                                                    $harga4 =  number_format($pagu3/1000000,2);
                                                                                                    if($harga4==0){
                                                                                                       $harga4=''; 
                                                                                                    }
                                                                                                    $harga5 =  number_format($pagu4/1000000,2);
                                                                                                    if($harga5==0){
                                                                                                       $harga5=''; 
                                                                                                    } 
                                                                                                    
                                                                                                     $cRet    .= " <tr>                                    
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"5%\">$ket</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga1</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga2</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga3</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga4</td>
                                                                                                                 <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga5</td>
                                                                                                                 </tr>
                                                                                                                 ";
                                                                                                   }
                                                                       }
                                                }
                                    
                                            $cRet .=       " </table>";
                                       }
                                
        
        
        $data['prev']= $cRet;    
        switch($ct) {       
        case 1;
            echo($cRet);
            //$this->template->load('template','master/kegiatan/cetak1',$data);
        break;
        case 2;
            $this->_mpdf('',$cRet,10,10,10,'1');
        break;
        case 3;        
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename= $judul.xls");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        case 4;     
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-word");
            header("Content-Disposition: attachment; filename= $judul.doc");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        } 
        
                
    }
    
    function preview_renstra_lokasi1($ct='1',$lokasi){
            
            $kd_skpd = $this->session->userdata('kdskpd');
            $thn_ang = $this->session->userdata('pcThang');
            $sqldns="select * from t_dept   WHERE kddept='$kd_skpd'";
                 $sqlskpd=$this->db->query($sqldns);
                 foreach ($sqlskpd->result() as $rowdns)
                {
                   
                    $kd_dept = $rowdns->kddept;
                    $nm_dept  = $rowdns->nmdept;
                }
            $sqllokasi="select * from t_lokasi   WHERE kdlokasi='$lokasi'";
                 $sqllok=$this->db->query($sqllokasi);
                 foreach ($sqllok->result() as $rowlok)
                {
                   
                    $kd_lok = $rowlok->kdlokasi;
                    $nm_lok  = $rowlok->nmlokasi;
                }
                        
            $thn_ang_2= $thn_ang+1;
            $thn_ang_3= $thn_ang+2;
            $thn_ang_4= $thn_ang+3;
            $thn_ang_5= $thn_ang+4;
            $cRet='';
                     $cRet .="<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
                                <tr>
                                     <td align=\"center\"><strong>ALOKASI BASELINE 2016-2019</strong></td>                         
                                </tr>
                                <tr>
                                     <td align=\"center\"><strong>$kd_dept:$nm_dept</strong></td>                         
                                </tr>
                                <tr>
                                     <td align=\"center\"><strong>$kd_lok:$nm_lok</strong></td>                         
                                </tr>                  
                                
                                <tr>
                                     <td align=\"center\">&nbsp;</td>
                                </tr>
                              </table>";   
                    
                            
                    $cRet .= "<table style=\"border-collapse:collapse;\" width=\"100%\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
                                 <thead>                       
                                    
             		                  <tr>  
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Program</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Kegiatan</td>
                                        <td width=\"15%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\" >Sasaran Kegiatan(Output)</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\" >Volume Output</td>
                                        <td width=\"10%\" bgcolor=\"#CCCCCC\" align=\"center\" rowspan=\"2\">Satuan</td>
                                        <td width=\"20%\" bgcolor=\"#CCCCCC\" align=\"center\" colspan=\"5\">Alokasi(Dalam Juta Rupiah)</td>
                                      </tr> 
                                      
                                      <tr>  
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_2</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_3</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_4</td>
                                        <td width=\"4%\" bgcolor=\"#CCCCCC\" align=\"center\" >$thn_ang_5</td>
                                      </tr>   
                                 </thead>
                                    ";
                             
                                 $sql="SELECT a.kdprogram,b.nmprogram,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4  FROM d_item_output_lokasi a INNER JOIN t_program b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram
                                        WHERE a.kddept='$kd_skpd' and a.kdlokasi='$lokasi' GROUP BY a.kdprogram,b.nmprogram ";
                                 $sqlp=$this->db->query($sql);
                                 foreach ($sqlp->result() as $rowp)
                                    {
                                       
                                        $kdprog=$rowp->kdprogram;
                                        $nama=$rowp->nmprogram;
                                        $total1 =  number_format($rowp->total/1000000,2);
                                        $total2 =  number_format($rowp->total1/1000000,2);
                                        $total3 =  number_format($rowp->total2/1000000,2);
                                        $total4 =  number_format($rowp->total3/1000000,2);
                                        $total5 =  number_format($rowp->total4/1000000,2);                  
                                         $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\">$kdprog-$nama</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$total5</td>
                                                         </tr>
                                                         ";
                                                         
                                            $sql1="SELECT a.kdgiat,b.nmgiat,sum(total) as total,sum(total1) as total1,sum(total2) as total2,sum(total3) as total3,sum(total4) as total4 FROM d_item_output_lokasi a INNER JOIN t_giat b ON a.kddept=b.kddept AND a.kdprogram=b.kdprogram AND a.kdgiat=b.kdgiat
                                                  WHERE a.kddept='$kd_skpd' AND a.kdprogram='$kdprog' and a.kdlokasi='$lokasi' GROUP BY a.kdgiat,b.nmgiat ";
                                                 $sqlp1=$this->db->query($sql1);
                                                 foreach ($sqlp1->result() as $rowp1)
                                                    {
                                                       
                                                        $kdgiat=$rowp1->kdgiat;
                                                        $nmgiat=$rowp1->nmgiat;
                                                        $tot1 =  number_format($rowp1->total/1000000,2);
                                                        $tot2 =  number_format($rowp1->total1/1000000,2);
                                                        $tot3 =  number_format($rowp1->total2/1000000,2);
                                                        $tot4 =  number_format($rowp1->total3/1000000,2);
                                                        $tot5 =  number_format($rowp1->total4/1000000,2); 
                                                                               
                                                        $cRet    .= " <tr>                                    
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat -$nmgiat</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\"></td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot1</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot2</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot3</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot4</td>
                                                         <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$tot5</td>
                                                         </tr>
                                                         ";
                                                                         
                                                         $sql2="SELECT * FROM d_item_output_lokasi 
                                                                    WHERE kddept='$kd_skpd' and kdprogram='$kdprog' AND kdgiat='$kdgiat' and kdlokasi='$lokasi' ";
                                                                 $sqlp2=$this->db->query($sql2);
                                                                 foreach ($sqlp2->result() as $rowp2)
                                                                    {
                                                                       
                                                                        $kdoutput=$rowp2->kdoutput;
                                                                        $nnmoutput=$rowp2->nmoutput;
                                                                        $satuan=$rowp2->satuan;
                                                                        $vol1=$rowp2->vol;
                                                                        if($vol1==0){
                                                                           $vol1=''; 
                                                                        }
                                                                        $vol2=$rowp2->vol1;
                                                                        if($vol2==0){
                                                                           $vol2=''; 
                                                                        }
                                                                        $vol3=$rowp2->vol2;
                                                                        if($vol3==0){
                                                                           $vol3=''; 
                                                                        }
                                                                        $vol4=$rowp2->vol3;
                                                                        if($vol4==0){
                                                                           $vol4=''; 
                                                                        }
                                                                        $vol5=$rowp2->vol4;
                                                                        if($vol5==0){
                                                                           $vol5=''; 
                                                                        }
                                                                        $hrg1 =  $rowp2->harga; 
                                                                        $hrg2 =  $rowp2->harga1;
                                                                        $hrg3 =  $rowp2->harga2;
                                                                        $hrg4 =  $rowp2->harga3;
                                                                        $hrg5 =  $rowp2->harga4;  
                                                                        $nilai1 =  $hrg1*$vol1; 
                                                                        $nilai2 =  $hrg2*$vol2;
                                                                        $nilai3 =  $hrg3*$vol3;
                                                                        $nilai4 =  $hrg4*$vol4;
                                                                        $nilai5 =  $hrg5*$vol5; 
                                                                        $harga1 =  number_format($nilai1/1000000,2);
                                                                        if($harga1==0){
                                                                           $harga1=''; 
                                                                        } 
                                                                        $harga2 =  number_format($nilai2/1000000,2);
                                                                        if($harga2==0){
                                                                           $harga2=''; 
                                                                        }
                                                                        $harga3 =  number_format($nilai3/1000000,2);
                                                                        if($harga3==0){
                                                                           $harga3=''; 
                                                                        }
                                                                        $harga4 =  number_format($nilai4/1000000,2);
                                                                        if($harga4==0){
                                                                           $harga4=''; 
                                                                        }
                                                                        $harga5 =  number_format($nilai5/1000000,2);
                                                                        if($harga5==0){
                                                                           $harga5=''; 
                                                                        }       
                                                                         $cRet    .= " <tr>                                    
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"20%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\"></td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"15%\">$kdprog.$kdgiat.$kdoutput-$nnmoutput</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\">$vol5</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"10%\">$satuan</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga1</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga2</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga3</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga4</td>
                                                                                     <td style=\"vertical-align:top;border-top: solid 1px black;border-bottom: none;\" width=\"4%\" align=\"right\">$harga5</td>
                                                                                     </tr>
                                                                                     ";
                                                                       }
                                                }
                                    
                                            $cRet .=       " </table>";
                                       }
                                
        
        
        $data['prev']= $cRet;    
        switch($ct) {       
        case 1;
            echo($cRet);
            //$this->template->load('template','master/kegiatan/cetak1',$data);
        break;
        case 2;
            $this->_mpdf('',$cRet,10,10,10,'1');
        break;
        case 3;        
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename= $judul.xls");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        case 4;     
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Content-Type: application/vnd.ms-word");
            header("Content-Disposition: attachment; filename= $judul.doc");
            $this->load->view('anggaran/rka/bappenas', $data);
        break;
        } 
        
                
    }
    
    function _mpdf($judul='',$isi='',$lMargin=10,$rMargin=10,$font=12,$orientasi='1') {
        
        ini_set("memory_limit","-1");
        $this->load->library('mpdf');
        
        /*
        $this->mpdf->progbar_altHTML = '<html><body>
	                                    <div style="margin-top: 5em; text-align: center; font-family: Verdana; font-size: 12px;"><img style="vertical-align: middle" src="'.base_url().'images/loading.gif" /> Creating PDF file. Please wait...</div>';        
        $this->mpdf->StartProgressBarOutput();
        */
        
        $this->mpdf->defaultheaderfontsize = 6;	/* in pts */
        $this->mpdf->defaultheaderfontstyle = BI;	/* blank, B, I, or BI */
        $this->mpdf->defaultheaderline = 1; 	/* 1 to include line below header/above footer */

        $this->mpdf->defaultfooterfontsize = 6;	/* in pts */
        $this->mpdf->defaultfooterfontstyle = BI;	/* blank, B, I, or BI */
        $this->mpdf->defaultfooterline = 1; 
        
        //$this->mpdf->SetHeader('SIMAKDA||');
        $jam = date("H:i:s");
        //$this->mpdf->SetFooter('Printed on @ {DATE j-m-Y H:i:s} |Simakda| Page {PAGENO} of {nb}');
        $this->mpdf->SetFooter('Printed on @ {DATE j-m-Y H:i:s} |Halaman {PAGENO} / {nb}| ');
        
        $this->mpdf->AddPage($orientasi);
        
        if (!empty($judul)) $this->mpdf->writeHTML($judul);
        $this->mpdf->writeHTML($isi);
         
        $this->mpdf->Output();
    }  
    
}


