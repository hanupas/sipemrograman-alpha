<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Master extends CI_Controller {

	function __contruct()
	{	
		parent::__construct();
	}
    
 
    
   function mskpd()
    {
        $data['page_title']= 'Master SKPD';
        $this->template->set('title', 'Master SKPD');   
        $this->template->load('template','master/skpd/mskpd',$data) ; 
    }
    
    function parameter()
    {
        $data['page_title']= 'Master SKPD';
        $this->template->set('title', 'Master SKPD');   
        $this->template->load('template','master/skpd/parameter',$data) ; 
    }
    
    function tambah_renstra()
	{
		
        $data['page_title']= 'Master Renstra';
        $this->template->set('title', 'Master Renstra');   
        
        $this->template->load('template','master/renstra/tambah_renstra',$data) ; 
   }
    
    function ambil_urusan() {
        $lccr = $this->input->post('q');
        $sql = "SELECT kd_urusan, nm_urusan FROM ms_urusan where upper(kd_urusan) like upper('%$lccr%') or upper(nm_urusan) like upper('%$lccr%') ";
        $query1 = $this->db->query($sql);  
        $result = array();
        $ii = 0;
        foreach($query1->result_array() as $resulte)
        { 
           
            $result[] = array(
                        'id' => $ii,        
                        'kd_urusan' => $resulte['kd_urusan'],  
                        'nm_urusan' => $resulte['nm_urusan']
                        );
                        $ii++;
        }
           
        echo json_encode($result);
    	   
	}
    
    function ambil_output($cskpd='',$cprog='',$cgiat='') {
        $lccr = $this->input->post('q');
        $sql = "SELECT kdnewoutput, nmoutput FROM t_new_output where kddept='$cskpd' and kdprogram='$cprog' and kdgiat='$cgiat' and (ket='1' or ket='4') group by kdnewoutput, nmoutput";
        $query1 = $this->db->query($sql);  
        $result = array();
        $ii = 0;
        foreach($query1->result_array() as $resulte)
        { 
           
            $result[] = array(
                        'id' => $ii,        
                        'kdnewoutput' => $resulte['kdnewoutput'],  
                        'nmoutput' => $resulte['nmoutput']
                        );
                        $ii++;
        }
           
        echo json_encode($result);
    	   
	}
    
    function lokasi() {
        $lccr = $this->input->post('q');
        $sql = "SELECT * from t_lokasi";
        $query1 = $this->db->query($sql);  
        $result = array();
        $ii = 0;
        foreach($query1->result_array() as $resulte)
        { 
           
            $result[] = array(
                        'id' => $ii,        
                        'kdlokasi' => $resulte['kdlokasi'],  
                        'nmlokasi' => $resulte['nmlokasi']
                        );
                        $ii++;
        }
           
        echo json_encode($result);
    	   
	}
    
    function load_skpd() {
        $result = array();
        $row = array();
      	$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
	    $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
	    $offset = ($page-1)*$rows;
        $kriteria = '';
        $kriteria = $this->input->post('cari');
        $where ='';
        if ($kriteria <> ''){                               
            $where="where (upper(nmdept) like upper('%$kriteria%') or kddept like'%$kriteria%')";            
        }
             
        $sql = "SELECT count(*) as tot from t_dept $where" ;
        $query1 = $this->db->query($sql);
        $total = $query1->row();
        
        
        
        $sql = "SELECT * from t_dept $where order by kddept limit $offset,$rows";
        $query1 = $this->db->query($sql);  
        $result = array();
        $ii = 0;
        foreach($query1->result_array() as $resulte)
        { 
           
            $row[] = array(
                        'id' => $ii,
                        'kd_skpd' => $resulte['kddept'],
                        'nm_skpd' => $resulte['nmdept']                                                                                       
                        );
                        $ii++;
        }
           
        $result["total"] = $total->tot;
        $result["rows"] = $row; 
        echo json_encode($result);
    	   
	}
    
     
    function simpan_master(){
        
        $tabel  = $this->input->post('tabel');
        $lckolom = $this->input->post('kolom');
        $lcnilai = $this->input->post('nilai');
        $cid = $this->input->post('cid');
        $lcid = $this->input->post('lcid');
        
        $sql = "select $cid from $tabel where $cid='$lcid'";
        $res = $this->db->query($sql);
        if($res->num_rows()>0){
            echo '1';
        }else{
            $sql = "insert into $tabel $lckolom values $lcnilai";
            $asg = $this->db->query($sql);
            if($asg){
                echo '2';
            }else{
                echo '0';
            }
        }
    }
    
    function simpan_master1(){
        $tabel  = $this->input->post('tabel');
        $lckolom = $this->input->post('kolom');
        $lcnilai = $this->input->post('nilai');
        $cprog = $this->input->post('cprog');
        $lcprog = $this->input->post('lcprog');
        $cgiat = $this->input->post('cgiat');
        $lcgiat = $this->input->post('lcgiat');
        $cid = $this->input->post('cid');
        $lcid = $this->input->post('lcid');
        $cidnew = $this->input->post('cidnew');
        $lcidnew = $this->input->post('lcidnew');

 
        
        $sql = "select $cid from $tabel where $cid='$lcid' and $cprog='$lcprog' and $cidnew='$lcidnew' and  $cgiat='$lcgiat'";
        $res = $this->db->query($sql);
        if($res->num_rows()>0){
            echo '1';
        }else{
            $sql = "insert into $tabel $lckolom values $lcnilai";
            $asg = $this->db->query($sql);
            if($asg){
                echo '2';
            }else{
                echo '0';
            }
        }
    }
    
    function update_master(){
        $query = $this->input->post('st_query');
        //$query1 = $this->input->post('st_query1');
        $asg = $this->db->query($query);
        if($asg){
            echo '1';
        }else{
            echo '0';
        }
        //$asg1 = $this->db->query($query1);
  

    }
    
    function hapus_renstra(){
        $prog = $this->input->post('prog');
        $giat = $this->input->post('giat');
        $output = $this->input->post('outout');
        $newoutput = $this->input->post('newoutput');
        $msg = array();
        $sql = "delete from t_new_output where kdprogram='$prog' and kdgiat='$giat' and kdoutput='$output' and kdnewoutput='$newoutput'";
        $asg = $this->db->query($sql);
    
    	
    
    	if ($asg){
            $msg = array('pesan'=>'1');
            echo json_encode($msg);
        } else {
            $msg = array('pesan'=>'0');
            echo json_encode($msg);
            
        }
    }
    
    function hapus_master(){
        //no:cnomor,skpd:cskpd
        $ctabel = $this->input->post('tabel');
        $cid = $this->input->post('cid');
        $cnid = $this->input->post('cnid');
        
        $csql = "delete from $ctabel where $cid = '$cnid'";
                
        //$sql = "delete from mbidang where bidang='$ckdbid'";
        $asg = $this->db->query($csql);
        if ($asg){
            echo '1'; 
        } else{
            echo '0';
        }
                       
    }
    
    function load_parameter() {
            
    	$sql = "select * from proyeksi";                   
            
            $query1 = $this->db->query($sql);  
            $result = array();
            $ii = 0;
            foreach($query1->result_array() as $resulte)
            { 
               
                $result[] = array(
                            'id' => $ii,        
                            'no' => $resulte['no'],  
                            'faktor' => $resulte['faktor'],  
                            'thn1' => $resulte['thn1'],
                            'thn2' => $resulte['thn2'],
                            'thn3' => $resulte['thn3'],
                            'thn4' => $resulte['thn4']                        
                                                          
                            );
                            $ii++;
            }
               
               echo json_encode($result);
                $query1->free_result();
        }
        
        function simpan_paramater(){
            $kd   = $this->input->post('kd');
            $thn1 =   $this->input->post('thn1');
            $thn2 =   $this->input->post('thn2');
            $thn3 =   $this->input->post('thn3');
            $thn4 =   $this->input->post('thn4');
                
                    
    				$sql = "update proyeksi set thn1='$thn1',thn2='$thn2',thn3='$thn3',thn4='$thn4'
                            where no='$kd' ";
                    $asg = $this->db->query($sql);
    
    
    
    
                    if (!($asg)){
                       $msg = array('pesan'=>'0');
                       echo json_encode($msg);
                        exit();
                    } else {
                        $msg = array('pesan'=>'1');
                        echo json_encode($msg);
                    }             
                
                
            
        }
    
}
